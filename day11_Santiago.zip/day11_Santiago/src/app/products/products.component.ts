//import the component from the 
import { Component } from "@angular/core";

@Component({
    selector:'products',//selecting a <product></product> tag
    templateUrl: './products.component.html',//where am i going to find selector
})
export class productsComponent{
    
}