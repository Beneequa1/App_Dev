import { Component } from '@angular/core';

@Component({
  selector: 'product',
  templateUrl: './product.component.html',
  /*inline styling  styles:['.p1{color:blue}'],*/
styleUrls: ['./product.component.scss']
})
export class ProductComponent {
firstName ='Peter'
lastName ='Pan'

productId:number =123
stockStatus:string ='Yes'

getStockStatus(){
  return this.stockStatus
}
}
