import React from 'react';
import ReactDOM from 'react-dom/client';
import User from './comments'
import avatarbatman from './images/batman.svg'
import avatarwink from './images/wink.svg'
import avatarafro from './images/afro.svg'
import User_feedback from './userfeedback'

const App =function(){
  return(
    <div className='ui comments'>
      <User_feedback>
      <User 
            name='Ms.wink'
            date='09:30AM'
            msg="I'm feeling amazing"
            picture={avatarwink}/>
            </User_feedback>
            <User_feedback>
      <User 
            name='Mr.Batman'
            date='10:26AM'
            msg="Where is the party"
            picture={avatarbatman}/>
            </User_feedback>
            <User_feedback>
      <User 
            name='Mr.Afro'
            date='01:52PM'
            msg="Where am i"
            picture={avatarafro}/>
            </User_feedback>
            
       
        </div>
  )
}



//rooting
const root = ReactDOM.createRoot(document.querySelector
  ('#root'))
root.render(App())




/* example of props
const App= function(props){
  return(
    <div>
      <h1>Welcome to React function components{props.name}</h1>
    </div>
  )
}
// create a props in a constant
const myElement=<App name='Martha'/>

// rooting
const root=ReactDOM.createRoot(document.querySelector('#root'))
render(

)
*/
