import React from 'react'
import User_feedback from './userfeedback'


const User =function(props){
    return(
        <div className='comments'>
            <a href='' className='avatar'>
                <img src={props.picture} alt='avatar of batman'/>
                 
            </a>
           
            <div className='content'>
                <a className='author'>
                    {props.name}
                    
                </a>
                
                <div classNmae='metadata'>
                    <span classNmae='date'>Today at {props.date}</span>
                    <div className='text'>
                        {props.msg}
                    </div>

                </div>
            </div>
        </div>
    
    )
}

    

export default User